<template>
  <div>财富</div>
</template>
