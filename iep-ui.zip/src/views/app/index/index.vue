<template>
  <div>国脉首页，游客可进入</div>
</template>
