<template>
  <div>
    wealth/index.vue
  </div>
</template>
