<template>
  <el-row class="contract">
    <el-col class="head" :span=24>合同概况</el-col>
  </el-row>
</template>

<style lang="scss" scoped>
.contract {
  .head {
    font-weight: 700;
    background-color: #eee;
    height: 40px;
    line-height: 40px;
    padding: 0 10px;
  }
}
</style>
