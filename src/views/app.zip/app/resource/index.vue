<template>
  <div>资源</div>
</template>
