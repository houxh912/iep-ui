<template>
  <div>collection/index.vue</div>
</template>
