const initAddAdminForm = () => {
  return {
    userId: '',
  }
}
export { initAddAdminForm }