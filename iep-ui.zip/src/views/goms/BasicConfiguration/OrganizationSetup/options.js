const initOrgForm = () => {
  return {
    id: '',
    name: '',
    logo: '',
    intro: '',
  }
}

export { initOrgForm }