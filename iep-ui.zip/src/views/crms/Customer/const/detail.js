export const initContactForm = () => {
  return {
    name: '',
  }
}

export const initVisitForm = () => {
  return {
    name: '',
  }
}

export const initConsultaForm = () => {
  return {
    name: '',
  }
}