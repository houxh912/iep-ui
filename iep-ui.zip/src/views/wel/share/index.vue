<template>
  <div>share/index.vue</div>
</template>
