<template>
  <div>
    mail/index.vue
  </div>
</template>
