<template>
  <div>学院</div>
</template>
