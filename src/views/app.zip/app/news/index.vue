<template>
  <div>要闻</div>
</template>
