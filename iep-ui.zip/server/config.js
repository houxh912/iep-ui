const config = {
  port: 5000
}

exports = module.exports = config
