<template>
  <div class="allCustom">全部客户</div>
</template>

<script>
export default {
  name: 'allCustom',
}
</script>
