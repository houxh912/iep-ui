<template>
  <div class="contract">合同</div>
</template>

<script>
export default {
  name: 'contract',
}
</script>
