// const pageColumnObj = {
//   id: '1', // 用户ID
//   name: '张超', // 姓名
//   sex: '男', // 性别
//   education: '大学', // 学历
//   age: '14', // 年龄
//   applyPosition: '14', // 应聘岗位
//   receptionTime: '2019-01-01', // 简历接收时间
//   source: '国脉官网', // 来源
//   remarks: '驳回原因', // 备注
//   birthday: '1985-06-04', // 出生年月
//   blacklistArea: '1985-06-04', // 拉黑地区
//   blacklistReason: '1985-06-04', // 拉黑原因
// }