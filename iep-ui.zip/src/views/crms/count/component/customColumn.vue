<template>
  <el-row class="custom">
    <el-col class="head">客户分析</el-col>
  </el-row>
</template>

<style lang="scss" scoped>
.custom {
  .head {
    font-weight: 700;
    background-color: #eee;
    height: 40px;
    line-height: 40px;
    padding: 0 10px;
  }
}
</style>
